module.exports = {
  host: "127.0.0.1",
  user: "admin",
  password: "7v8$016qqjn^dda4",
  database: "chainb",
  port: 3306
}