// (testuserpsd + salt) md5
module.exports = {
  TEST_USER: {
    "address": "testuseraddress",
    "ID": 10001,
    "balance": 0,
    "passWord": "b04a7ca45ee3f3afe375161a120f9eaa",
    "privateKey": "testuserprivatekey"
  }
}